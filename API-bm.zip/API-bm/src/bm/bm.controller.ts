import { Controller } from '@nestjs/common';

@Controller('bm')
export class BmController {}
