export interface BmBm { 
    readonly description: string;
    readonly isDone: boolean;
}